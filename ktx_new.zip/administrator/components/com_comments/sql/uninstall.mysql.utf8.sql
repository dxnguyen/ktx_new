DROP TABLE IF EXISTS `#__comments`;
